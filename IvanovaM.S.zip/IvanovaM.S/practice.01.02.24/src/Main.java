import com.sun.source.tree.Tree;

import java.util.*;

public class Main {
    public static void main(String[] args) {
//        //1
//        HashSet<String> fruit = new HashSet<>();
//        fruit.add("Banana");
//        fruit.add("Apple");
//        fruit.add("Mango");
//        fruit.add("Orange");
//        fruit.add("Orange");
//        System.out.println("fruit: " + fruit);
//        System.out.println("size: " + fruit.size());
//        // 2
//        LinkedHashSet<String> ll = new LinkedHashSet<>();
//        ll.add("aaa");
//        ll.add("bbb");
//        ll.add("ccc");
//        ll.add("ccc");
//        System.out.println(ll);
//      //  ll.remove("bbb");
//      //  System.out.println(ll);
//        // 3
//        SortedSet<Integer> fruit1 = new TreeSet<>();
//        fruit1.add(26);
//        fruit1.add(55);
//        fruit1.add(3);
//        fruit1.add(280);
//        System.out.println(fruit1);
//        System.out.println(fruit1.first());
//        System.out.println(fruit1.last());
//        System.out.println(fruit1.headSet(55));
//        System.out.println(fruit1.tailSet(26));
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите набор чисел: ");
        String input = scanner.nextLine();
        String input2 = scanner.nextLine();
        String input3 = scanner.nextLine();
        String input4 = scanner.nextLine();
        String input5 = scanner.nextLine();
        Set<String> hashSet = new HashSet<>();
        Set<String> hashSet2 = new HashSet<>();
        Set<String> hashSet3 = new HashSet<>();
        Set<String> hashSet4 = new HashSet<>();
        Set<String> hashSet5 = new HashSet<>();
        hashSet.add(input);
        hashSet2.add(input2);
        hashSet3.add(input3);
        hashSet4.add(input4);
        hashSet5.add(input5);

        System.out.println("Добавить элемент в список");
        System.out.println("Удалить элемент из списка");
        System.out.println("Показать содержимое списка");
        System.out.println("Проверить есть ли значение в списке");
        System.out.println("Заменить значение в списке");
    }
}
