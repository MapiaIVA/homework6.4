import java.util.*;
import java.util.stream.Stream;

public class Main {
//    private static int[]generationRandomNumber(int count) {
//        int []numbers = new int[count];
//        Random random = new Random();
//        for (int i = 0; i < count; i++) {
//            numbers[i]=random.nextInt();
//        }
//        return numbers;
//    }
    public static void main(String[] args) {


       // int[]numbers = generationRandomNumber(100);
        List<Integer>numbers = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            numbers.add((random.nextInt(100)));
        }


        int countNumber = (int)numbers.stream().filter(f->f%2==0).count();
        int countNumbers1 = (int)numbers.stream().filter(f->f%2!=0).count();
        int countNumbers12 = (int)numbers.stream().filter(f->f==0).count();
        Scanner scanner = new Scanner(System.in);
        System.out.println("введите число; ");
        int s = scanner.nextInt();
        System.out.println(s);
//
//
//        int countNumbers123 = (int)numbers.stream().filter(f->f==s).count();
//        System.out.println(countNumbers123);
//        System.out.println(countNumber);
//        System.out.println(countNumbers1);
//        System.out.println(countNumbers12);
//
//
//
//
//
//        int twos;
//        twos = Arrays.stream(numbers).filter((thr)->thr.%2=0);
//        List<City> cities = new ArrayList<>();
//
//
//        Stream.of("Moscow","Leningrad", "Kaliningrad", "Volgograd", "Moscow").forEach(c-> System.out.println(c));
//        System.out.println("Города которые начинаются на букву L: ");
//        Stream.of("Moscow","Leningrad", "Kaliningrad", "Volgograd", "Moscow").filter((c)->c.startsWith("L")).forEach(c-> System.out.println(c));
//        Stream.of("Moscow","Leningrad", "Kaliningrad", "Volgograd", "Moscow").filter((c)->c.length()>6).forEach(c-> System.out.println(c));
//
//        Scanner scanner = new Scanner("Введите число для сравнения");
//    String s = scanner.nextLine();
//       System.out.println(s);
//
//
//        Stream.of("Moscow","Leningrad", "Kaliningrad", "Volgograd", "Moscow").filter((c)->c.).forEach(c-> System.out.println(c));






    }
}