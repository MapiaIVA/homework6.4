

@FunctionalInterface
interface MyInterface<T> {
    T func(T t);
}

 //   double getpiValue();
//    String reverse(String n);


public class Main {
    public static void main(String[] args) {
        MyInterface<String> reverse = (str) -> {
            String result = "";
            for (int i = str.length() - 1; i >= 0; i--) {
                result += str.charAt(i);
            }
            return result;
        };
        System.out.println("Лямда выражение: " + reverse.func("jdikjsss"));

        MyInterface<Integer> factorial = (n) -> {
            int result = 1;
            for (int i = 1; i <= n; i++) {
                result = i * result;
            }
            return result;
        };
        System.out.println("Факториал от 5 = : " + factorial.func(5));
    }
}
//        MyInterface ref = (str) -> {
//            String result = " ";
//            for (int i = str.length()-1; i >=0; i--) {
//                result += str.charAt(i);
//
//
//            }
//            return result;
//        };
//        System.out.println("Лямда выражение: " + ref.reverse("jfdkdks"));


//        ref = () -> 3.1415;
//        System.out.println("Значение числа PI = " + ref.getpiValue());


//    (n)->(n%2)==0


//        double getPiValue() {
//            return 3.1415;
//        }
//        //      ()->3.1415
////        double getPiValue2()->3.1415;
////    ()->System.out.println("dshjd");


