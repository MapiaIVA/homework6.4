
public class Main {
    public static void main(String[] args) {
        Worker president = new President();
        Worker security = new Security();
        Worker manager = new manager();
        Worker engineer = new Engineer();
        president.Print();
        security.Print();
        manager.Print();
        engineer.Print();
    }

}
abstract class Worker {
    public abstract void Print();
}
class President extends Worker {

    @Override
    public void Print() {
        System.out.println("Информация о президенте: ");
    }
}
class Security extends Worker {

    @Override
    public void Print() {
        System.out.println("Информация об охраннике:");
    }
}
class manager extends Worker {

    @Override
    public void Print() {
        System.out.println("Информация о менеджере: ");
    }
}
class Engineer extends Worker {

    @Override
    public void Print() {
        System.out.println("Информация об инженере: ");
    }
}

