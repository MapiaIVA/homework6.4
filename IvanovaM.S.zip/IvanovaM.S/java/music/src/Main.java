public class Main {
    public static void main(String[] args) {
        musical musical  = new musical("Устройство ");
        skripka skripka = new skripka("Скрипка");
        trombon trombon = new trombon("Тромбон");
        ukulele ukulele = new ukulele("укулеле");
        violonchel violonchel = new  violonchel("виолончель");
        musical.show();
        musical.desc();
        musical.Sound();
        musical.history();
        skripka.desc();
        skripka.show();
        skripka.Sound();
        skripka.history();
        trombon.desc();
        trombon.show();
        trombon.Sound();
        trombon.history();
        ukulele.show();
        ukulele.desc();
        ukulele.Sound();
        ukulele.history();
        violonchel.desc();
        violonchel.show();
        violonchel.Sound();
        violonchel.history();
    }

}
class musical  {
    private String name;
    public musical(String name) {
        this.name = name;
    }
    public void Sound() {
        System.out.println("звук устройства ");
    }
    public void show() {
        System.out.println(" Название устройства: " + name);
    }
    public void desc() {
        System.out.println("описание устройства ");
    }
    public void history() {
        System.out.println("история музыкального инструмента");
    }
}
class skripka extends musical {
    public skripka(String name) {
        super(name);
    }
}
class  trombon extends musical {
    public trombon(String name) {
        super(name);
    }
}
class ukulele extends musical{
    public ukulele(String name) {
        super(name);
    }
}
class violonchel extends musical {
    public violonchel(String name) {
        super(name);
    }
}


