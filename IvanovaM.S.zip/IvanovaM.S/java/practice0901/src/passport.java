public class passport {
    public static void main(String[] args) {
        Human Ivan = new Human("Иванов Иван Иванович", "Moscow", "Russia", "red", 25121991, 892132435);
        System.out.println(Ivan.getFio());
        System.out.println(Ivan.getCounter());
        Human Maria = new Human("Иванова Мария Сергеевна", "Moscow", "Russia", "red", 25121991, 892132435);

        System.out.println(Maria.getFio());
        System.out.println(Maria.getCounter());



    }
}
