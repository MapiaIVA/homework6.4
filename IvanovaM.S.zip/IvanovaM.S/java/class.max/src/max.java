import java.util.Arrays;

public class max {
    private int q;
    private int w;
    private int e;
    private int r;

    public max(int q, int w, int e, int r) {
        this.q = q;
        this.w = w;
        this.e = e;
        this.r = r;
    }

    public int q() {
        return this.q;
    }

    public void q(int q1) {
        this.q = q1;
    }

    public int w() {
        return this.w;
    }

    public void w(int w1) {
        this.w = w1;
    }

    public int e() {
        return this.e;
    }

    public void e(int e1) {
        this.e = e1;
    }

    public int r() {
        return this.r;
    }

    public void r(int r1) {
        this.r = r1;
    }
    public int getMinNumber () {
        int[] arr = {q, w, e, r};
        Arrays.sort(arr);
        return arr[arr.length - 1];
    }
    public int getMaxNumber () {
        int[] arr = {q, w, e, r};
        Arrays.sort(arr);
        return arr[0];
    }
}

