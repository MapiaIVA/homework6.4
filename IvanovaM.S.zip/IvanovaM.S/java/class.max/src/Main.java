// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    private int p;
    private int i;
    private int y;
    private int t;

    public Main(int p, int i, int y, int t) {
        this.p = p;
        this.i = i;
        this.y = y;
        this.t = t;
    }

    public int p() {
        return this.p;
    }

    public void p(int p1) {
        this.p = p1;
    }

    public int i() {
        return this.i;
    }

    public void i(int i1) {
        this.i = i1;
    }

    public int y() {
        return this.y;
    }

    public void y(int y1) {
        this.y = y1;
    }

    public int t() {
        return this.t;
    }

    public void t(int t1) {
        this.t = t1;
    }


    public int getPghf() {
        //         return i > t ? (i > y ?  i : y) : (t > y ? t : y);
return (i + t + i + p)/4 ;
    }
}

