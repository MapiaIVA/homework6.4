public class result {
    public static void main(String[] args) {
        Main main = new Main(1, 2, 3, 4);
        max max1 = new max(3,4,5,6);
        System.out.println((main));
        System.out.println(main.getPghf());
        System.out.println(max1.getMaxNumber());
        System.out.println(max1.getMinNumber());
    }
}s
