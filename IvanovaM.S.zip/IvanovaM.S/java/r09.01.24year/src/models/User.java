package models;

public class User {
    private String firstname;
    private String secondName;
    private String birthday;
    private String email;
    private String login;
    private String password;

    public static int counter = 0;

    public User (String firstname, String secondName, String birthday, String email, String login, String password) {
        this.firstname = firstname;
        this.secondName = secondName;
        this.birthday = birthday;
        this.email = email;
        this.login = login;
        this.password = password;
        counter++;

    }
     public String getFirstname() {
        return this.firstname;
     }
     public void setFirstname (String newName) {
        this.firstname = newName;
     }
     public int getCounter() {
        return this.counter;
     }

    @Override
    public String toString() {
        return "Это новый пользователь, и его зовут " + firstname + "\n" + "его фамилия" + secondName;
    }
}
