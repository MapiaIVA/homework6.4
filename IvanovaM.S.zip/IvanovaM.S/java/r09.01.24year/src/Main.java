import models.User;

public class Main {
    public static void main(String[] args) {
        User newUser = new User("Мария", "Иванова", "17.06", "mamahsa2005@gmail.com", "maria", "asdfg12345");
        System.out.println(newUser.getFirstname());
        System.out.println(newUser.getCounter());
        User newUser2 = new User("Мария", "Иванова", "17.06", "mamahsa2005@gmail.com", "maria", "asdfg12345");



        System.out.println(newUser2.getFirstname());
        System.out.println(newUser2.getCounter());
        }
    }
