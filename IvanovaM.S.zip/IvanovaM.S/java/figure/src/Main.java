import java.awt.*;

import static java.lang.Math.*;

public class Main {
    public static void main(String[] args) {
       Figure[]figures = new Figure[4];
       figures[0]=new Pryamo(5,10);
       figures[1] = new Krug(3);
       figures[2] = new PrymTreugol(7,10);
       figures[3] = new Trapecia(3,5,8);
       for (Figure figure:figures) {
           System.out.println("площадь фигуры: " + figure.Calculat());
       }
    }

}
abstract class Figure {
    abstract double Calculat();
}
class Pryamo extends Figure {
    private double a;
    private double b;
    Pryamo (double a, double b) {
        this.a = a;
        this.b = b;
    }
    double Calculat() {
        return a * b;
    }
}
class Krug extends Figure {
    private double a;
    Krug (double a) {
        this.a = a;
    }
    double Calculat() {
        return PI*a*a;
    }
}
class  PrymTreugol extends Figure {
    private double a;
    private double b;
    PrymTreugol (double a, double b) {
        this.a = a;
        this.b = b;
    }
    double Calculat() {
        return (a * b)/2;
    }

}
class Trapecia extends Figure {
    private double a;
    private double b;
    private double h;
    Trapecia (double a, double b, double h) {
        this.a = a;
        this.b = b;
        this.h = h;
    }
    double Calculat() {
        return ((a + b)/2) * h;
    }
}


