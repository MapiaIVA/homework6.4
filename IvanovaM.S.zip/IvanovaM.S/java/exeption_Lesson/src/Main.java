
public class Main {

        public static char getCharFromString(String str, int index) throws IllegalArgumentException,
                IndexOutOfBoundsException {
            if (index < 0) {
                throw new IllegalArgumentException();

            }
            return str.toCharArray()[index];
        }
    public static void main(String[] args) {
            try {
                System.out.println(getCharFromString("hello", 20));
            } catch (IllegalArgumentException e) {
                System.out.println("индекс не может быть меньше нуля");
            }
            catch (IndexOutOfBoundsException e) {
                System.out.println("Вы вышли за пределы массива ");
            }
//        foo();
//    }
//    static Object object;
//    public static void foo() {
//        try {
//            System.out.println(1 / 0);
//        } catch (ArithmeticException e) {
//            System.out.println("На ноль делить нельзя");
//        } finally {
//        } try {
//            System.out.println(object.toString());
//        }
//        catch (NullPointerException e) {
//            System.out.println("Объект равен нулю");
//        }
//        throw new NullPointerException();
//        throws
    }
}
