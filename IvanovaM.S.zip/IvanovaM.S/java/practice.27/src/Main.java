import java.util.Scanner;

//import java.util.Scanner;
//public class Main {
//    public static char User(String a, int index) throws IndexOutOfBoundsException {
//        if (index <= 9) {
//            throw new IllegalArgumentException();
//        }
//        return a.toCharArray()[index];
//    }
//    static {
//        Scanner s = new Scanner(System.in);
//        System.out.println(s);
//    }
//
//    public static void main(String[] args) {
//        try {
//            System.out.println(10);
//        } catch (IndexOutOfBoundsException e) {
//            System.out.println("вы вышли за границы диапазона");
//        }
//        }
//    }
//public class Main {
//
//
//    public static void main(String[] args) {
////        Scanner scanner = new Scanner(System.in);
////        System.out.println("Введите число");
////        String input = scanner.nextLine();
////        try {
////            int number = Integer.parseInt(input);
////            System.out.println("Преобразованное число" + number);
////
////        } catch (NumberFormatException e) {
////            System.out.println("Ошибка преобразования: Введеная строка не является числом или выход за границу диапазона");
////
////        }
//    }
//}
//public class Main {
//    public static void main(String[] args) {
//        Scanner scanner1 = new Scanner(System.in);
//        System.out.println("Введите число от 0 до 1");
//        String input1 = scanner1.nextLine();
//        try{
//            int number1 = Integer.parseInt(input1, 2);
//            System.out.println("Преобразованное число: " + number1);
//        } catch (NumberFormatException e) {
//            System.out.println("Ошибка преобразования: введеная строка не является двоичным числом или выходит за границы диапазона int");
//
//        }
//    }
//}
public class Main {
    public static void main(String[] args) {
        Scanner scanner2 = new Scanner(System.in);
        System.out.println("Введите математическое выражение: ");
        String input2 = scanner2.nextLine();
        try {
            int result3 = evalueteExpression(input2);
            System.out.println("результат" + result3);
        } catch (Exception e) {
            System.out.println("Ошибка" + e.getMessage());
        }
    }
        public static int evalueteExpression (String ex) throws Exception {
            int result = 0;
            int currentNumber = 0;
            char operator = '+';
            for (int i = 0; i < ex.length(); i++) {
                char ch = ex.charAt(i);
                if (Character.isDigit(ch)) {
                    currentNumber = currentNumber * 10 + (ch - '0');
                }
                if (!Character.isDigit(ch) && ch != ' ' || i == ex.length() - 1) {
                    if (operator == '+') {
                        result += currentNumber;
                    } else if (operator == '-') {
                        result -= currentNumber;
                    } else {
                        throw new Exception("Некорректный оператор: " + operator);
                    }
                    operator = ch;
                    currentNumber = 0;
                }
            }
            return result;
        }
    }



























