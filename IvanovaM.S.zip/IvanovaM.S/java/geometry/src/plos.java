public class plos {
    public static void main(String[] args) {
        Main square = new Main(3, 5);
        Main square1 = new Main(4, 5);
        Trigon trigon = new Trigon(6,5);
        square1 square11 = new square1(8);
        romb romb1 = new romb(5,2,8,1);
        System.out.println(square);
        System.out.println(square.toInt());
        System.out.println(square1);
        System.out.println(square1.toInt());
        System.out.println(trigon);
        System.out.println(trigon.getOut());
        System.out.println(square11);
        System.out.println(square11.getIn());
        System.out.println(square11.getCounter());
        System.out.println(romb1);
        System.out.println(romb1.getSwq());


    }
}
