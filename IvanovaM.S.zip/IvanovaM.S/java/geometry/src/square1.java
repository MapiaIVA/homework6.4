public class square1 {
    private int v;
    public static int counter = 0;
    public square1(int v) {
        this.v = v;
        counter++;
    }
    public int v() {
        return this.v;
    }
    public void v (int v1) {
        this.v = v1;
    }
    public int getCounter() {
        return this.counter;
    }
    public int getIn() {
        return v * v;

    }
}

