public class Trigon {
    private int b;
    private int g;
    public Trigon(int b, int g) {
        this.b = b;
        this.g = g;
    }
    public int g() {
        return this.g;
    }
    public void g (int g1) {
        this.g = g1;
    }
    public int b() {
        return this.b;
    }
    public void b (int b1) {
        this.b = b1;
    }


    public int getOut() {
        return (b * g) / 2;

    }
}
