
public class Main {
    private int c;
    private int a;

//    private int o;



    public static int counter = 0;

    public Main(int a, int c) {
        this.a = a;
        this.c = c;
        counter++;

    }
    public int a() {
        return this.a;
    }
    public void a (int a1) {
        this.a = a1;
    }
    public int c() {
        return this.c;
    }
    public void c (int c1) {
        this.c = c1;
    }

//    public int o() {
//        return this.o;
//    }
//    public void o (int o1) {
//        this.o = o1;
//    }

    public int getCounter() {
        return this.counter;
    }

    public int toInt() {
        return a * c;
    }

}
