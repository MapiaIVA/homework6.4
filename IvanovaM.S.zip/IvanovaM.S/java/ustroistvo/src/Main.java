public class Main {
    public static void main(String[] args) {
        ustroistvo ustroistvo = new ustroistvo("Устройство ");
        chainik chainik = new chainik("Чайник");
        microwave microwave = new microwave("Микроволновка");
        auto auto = new auto("Автомобиль");
        parohod parohod = new parohod("Пароход");
        ustroistvo.show();
        ustroistvo.desc();
        ustroistvo.Sound();
        chainik.desc();
        chainik.show();
        chainik.Sound();
        microwave.desc();
        microwave.show();
        microwave.Sound();
        auto.show();
        auto.desc();
        auto.Sound();
        parohod.desc();
        parohod.show();
        parohod.Sound();
    }

}
class ustroistvo {
    private String name;
    public ustroistvo(String name) {
        this.name = name;
    }
    public void Sound() {
        System.out.println("звук устройства ");
    }
    public void show() {
        System.out.println(" Название устройства: " + name);
    }
    public void desc() {
        System.out.println("описание устройства ");
    }
}
class chainik extends ustroistvo {
    public chainik(String name) {
        super(name);
    }
}
    class microwave extends ustroistvo {
        public microwave(String name) {
            super(name);
        }
}
        class auto extends ustroistvo {
            public auto(String name) {
                super(name);
            }
}
class parohod extends ustroistvo {
    public parohod(String name) {
        super(name);
    }
}



