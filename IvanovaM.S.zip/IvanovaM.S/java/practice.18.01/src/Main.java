import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        VirtualCollection<Integer> collection = new VirtualCollection<>();
        collection.add(1);
        collection.add(55);
        collection.add(3);
        collection.add(4);
        collection.add(5);
        collection.sort();
        System.out.print(collection);

    }
}

class VirtualCollection<T extends Number> {
    private T[] array;

    public VirtualCollection() {
        array = (T[]) new Number[0];
    }

    public void print() {
        for (T anArray : array) {
            System.out.print(anArray + " ");
        }
        System.out.println();
    }

    public void add(T newValue) {
        T[] newArray = Arrays.copyOf(array, array.length + 1);
        this.array = newArray;
        array[array.length - 1] = newValue;
    }

    public void sort() {
        Arrays.sort(array);
    }
}
