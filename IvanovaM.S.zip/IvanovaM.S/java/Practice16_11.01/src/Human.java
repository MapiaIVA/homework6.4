public class Human {
    private String name;
    private String birthDay;
    private String phoneNumber;

    private static int counter = 0;

    public Human(String name, String birthDay, String phoneNumber) {
        this.name = name;
        this.birthDay = birthDay;
        this.phoneNumber = phoneNumber;
        counter++;
    }
    public String toString() {
        return "Нового человека зовут" + name + "\n" + "Он родился" + birthDay + "\n" + "его телефон: " + phoneNumber;
    }
    public String  getName() {
        return this.name;
    }
    public void setName(String newName) {
        this.name = newName;
    }
    public int getCounter() {
        return this.counter;
    }

}
