// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Human misha = new Human("Misha","04.03.1998","+79097791464");
        System.out.println(misha);
        System.out.println(misha.getName());
        misha.setName("Misha");
        System.out.println(misha.getName());
        System.out.println(misha.getCounter());
        }
    }