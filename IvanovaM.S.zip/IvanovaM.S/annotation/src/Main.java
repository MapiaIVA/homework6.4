import java.lang.annotation.*;

//
//@Target({ElementType.TYPE})
//
//@interface CodeAuthor {
//    String name();
//    int version() default 1;
//    String edited() default "01/01/1970";
//    String[] assistants();
//}
//@interface CodeAuthor {
//    String name();
//    int version();
//    String edited();
//    String[] assistants();
//}
@Inherited
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@interface Company{
    String name() default "abc";
    String city() default "xwz";
}



public class Main {
    public static void main(String[] args) {
        CustomAnnotationEmployee customAnnotationEmployee = new CustomAnnotationEmployee(1,"Jons");
        customAnnotationEmployee.getEmployeeDetails();
        Annotation companyAnnotation = customAnnotationEmployee.getClass().getAnnotation(Company.class);
        Company company = (Company) companyAnnotation;
        System.out.println("Company name: " + company.name());
        System.out.println("Company city: " + company.city());
        CustomAnnotationManager customAnnotationManager = new CustomAnnotationManager(1,"Jons");
        customAnnotationManager.getEmployeeDetails();
        Annotation companyAnnotation1 = customAnnotationManager.getClass().getAnnotation(Company.class);
        Company company1 = (Company) companyAnnotation1;
        System.out.println("Company name: " + company1.name());
        System.out.println("Company city: " + company1.city());


//        @CodeAuthor (name = "Indiana Jones", assistants = {"Marion", "Sallah"}
//        )
//                class LostArk
//        {
//
//            //class members
//        }
//
//
//        }
//    }
//    @Entity
//class Picture {
//        @PrimaryKey
//        protected Integer pictureId;
//        @Persistent
//        protected String pictureName = null;
//
//        @Getter
//        public String getPictureName() {
//            return this.pictureName;
//        }
//        @Setter
//        public void setPictureName(@Optional pictureName) {
//            this.pictureName = pictureName;
        }
    }
    @Company()
    class CustomAnnotationEmployee {
        int id;
        String name;

        public CustomAnnotationEmployee(int id, String name) {
            this.id = id;
            this.name = name;
        }
        public void getEmployeeDetails() {
            System.out.println("Employee id: " + id);
            System.out.println("Employee name: " + name);
        }
    }
    class CustomAnnotationManager extends CustomAnnotationEmployee{

        public CustomAnnotationManager(int id, String name) {
            super(id, name);
        }
    }


