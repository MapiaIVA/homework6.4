import java.util.ArrayList;
import java.util.Iterator;

public class Main {
    public static void main(String[] args) {
        ArrayList al = new ArrayList<>();
        ArrayList al1 = new ArrayList<>();
        int[] array = new int[10]; // длина массива
        for (int i = 0; i < array.length; i++) {
            array[i] = (int) (Math.random() * 100 + 1);
        }
        System.out.println("----");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
        for (int i = 0; i < array.length; i++) {
            if (array[i] >= 10) {
                al.add(array[i]);
            }
        }
        for (int i = 0; i < array.length; i++) {
            if (array[i]<10){
                al1.add(array[i]);
            }
        }
        Iterator it1 = al1.iterator();
        while (it1.hasNext()) {
            System.out.println(it1.next());
        }
        Iterator it = al.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }
        ArrayList<Integer>al3 = new ArrayList<Integer>();
        al3.add(1);
        al3.add(2);
        al3.add(3);
        al3.add(4);
        al3.add(5);
        System.out.println("----"+listTest(al3,3));
        }
        static int listTest(ArrayList<Integer>al,Integer s) {
        return al.indexOf(s);
        }

    }
