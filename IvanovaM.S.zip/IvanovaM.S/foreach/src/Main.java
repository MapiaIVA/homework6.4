import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {

//        Stream.of("Argentina","Bulgar", "Canada", "Denmark", "Russia", "USA").filter((c)->c.startsWith("U")).forEach(c-> System.out.println(c));

//        Stream.of("Argentina","Bulgar", "Canada", "Denmark", "Russia", "USA").map(String::toUpperCase).forEach(c-> System.out.println(c));




//        List<Integer> items = new ArrayList<>();
//        items.add(11);
//        items.add(35);
//        items.add(89);
//        items.add(5);
//        items.add(4357);
//        items.add(982);
//        items.forEach(item-> System.out.println(item));
//
//        List<Integer> squares = items.stream().map((i)-> i*i).collect(Collectors.toList());
//        System.out.println("В квадрате: ");
//        squares.forEach(item-> System.out.println(item));



//        items.forEach(item-> {
//            if(item>100) {
//                int index = items.indexOf(item);
//                items.set(index,item/10);
//            }
//        });
//        System.out.println("После: ");








        List<Fish> fishes = new ArrayList<>();
        fishes.add(new Fish("eel",1.5,120));
        fishes.add(new Fish("salmon",2.5,180));
        fishes.add(new Fish("carp",3.5,80));
        fishes.add(new Fish("tuna",4.2,320));
        fishes.add(new Fish("trout",2.8,150));

        double cost1 = fishes.stream().filter(f->f.getPrice()>100).mapToDouble(Fish::getPrice).sum();
        System.out.println("cost1: "+ cost1);
        fishes.forEach(System.out::println);

        IntStream.of(1,2,3,5,7,9,8,12,45).forEach((c)->System.out.println(c));

//        fishes.forEach(f-> System.out.println(f));
//        fishes.stream().filter(f->f.getPrice()>100).forEach(f-> f.setPrice(f.getPrice()*0.9));
//        System.out.println("После: ");
//        fishes.forEach(f-> System.out.println(f));
//
//        List<Fish> selected = fishes.stream().filter(f->f.getPrice()>100).collect(Collectors.toList());
//        System.out.println("После: ");
//        selected.forEach(f-> System.out.println(f));
//
//        int number = (int)fishes.stream().filter(f->f.getPrice()>100).count();
//        double cost = fishes.stream().filter(f->f.getPrice()>100).mapToDouble(f->f.getPrice()).sum();
//        System.out.println("Количество: " + number + " стоимость: " + cost);







    }
}
    class Fish
{
    private String name;
    private double weight;
    private double price;

    public Fish(String name, double weight, double price)
    {
        this.name=name;
        this.weight=weight;
        this.price=price;
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (!(o instanceof Fish))
        {
            return false;
        }
        Fish tmp = (Fish) o;
        return (tmp.name.equals(this.name) &&
                tmp.weight == this.weight &&
                tmp.price == (this.price));
    }

    public int hashCode()
    {
        return this.name.hashCode();
    }


    public double getWeight()
    {
        return this.weight;
    }
    public double getPrice()
    {
        return this.price;
    }
    public void setPrice(double price) {
        this.price = price;

    }


    @Override
    public String toString() {
        return this.name+" weight: "+this.weight+" price: "+this.price;
    }
}