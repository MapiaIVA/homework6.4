import java.lang.annotation.*;

@Inherited
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@interface Something {
    int first() default 20;
    int second() default 30;

}




public class Main {
    public static void main(String[] args) {
        SomethingFirst somethingFirst = new SomethingFirst(10);
        Annotation somethingAnnotation = somethingFirst.getClass().getAnnotation(Something.class);
        Something something = (Something) somethingAnnotation;
        somethingFirst.Calculator(something.first(),something.second());

        SomethingSecond somethingFirst1 = new SomethingSecond(10);
        Annotation somethingAnnotation1 = somethingFirst1.getClass().getAnnotation(Something.class);
        Something something1 = (Something) somethingAnnotation1;
        somethingFirst1.Calculator1(something1.first(),something1.second());

        SomethingString somethingString = new SomethingString("name");
        Annotation somethingAnnotation2 = somethingString.getClass().getAnnotation(Something.class);
        Something something2 = (Something) somethingAnnotation2;
        somethingString.Stroka(something2.first(),something2.second());


    }
}
@Something()
class SomethingFirst {
    int first;

    public SomethingFirst(int first) {
        this.first = first;
    }

    public void Calculator (int a, int b) {
        int c;
        c = (a + b) * first;
        System.out.println(" (a + b)*first = " + c);
    }
}
@Something
class SomethingString {
    String name;
    public SomethingString(String name) {
        this.name = name;
    }
    public void Stroka(int a, int b) {
        int c;
        c = a + b;
        for (int i = 0; i < c; i++) {
            System.out.println(name);
        }
    }



}

class SomethingSecond extends SomethingFirst {


    public SomethingSecond(int first) {
        super(first);
    }

    public void Calculator1 (int a, int b) {
        int c;
        c = (a + b) / first;
        System.out.println(" (a + b)/first = " + c);
    }
}
