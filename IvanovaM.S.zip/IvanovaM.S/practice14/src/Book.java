public class Book {
    private String name;
    private String writer;
    private int year;
    private String creator;
    private int page;


    private static int counter = 0;

    public Book(String name, String writer, String creator, int year, int page) {
        this.name = name;
        this.writer = writer;
        this.creator = creator;
        this.year = year;
        this.page = page;
    }

    public Book() {
        this.name = "Борис Годунов";
        this.writer = "Пушкин";
        this.creator = "Литрес";
        this.year = 1831;
        this.page = 200;
        counter++;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }






    @Override
    public String toString() {
        return name + " " + creator + " " + writer + " " + page + " " + year + " " + "\n" + counter;
    }
}


