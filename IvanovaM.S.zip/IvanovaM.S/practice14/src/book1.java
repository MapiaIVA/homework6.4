public class book1 {
    public static void main(String[] args) {
        Book Boris = new Book();
        System.out.println(Boris);

    }
}
