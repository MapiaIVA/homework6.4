public class Main {
    public static void main(String[] args) {
        City Kaliningrad = new City();
        System.out.println(Kaliningrad);
        System.out.println(Kaliningrad.getPeople());
        Kaliningrad.setPeople(4500000);
        System.out.println(Kaliningrad.getPeople());
        City Moscow = new City();
        System.out.println(Kaliningrad);

    }
}
