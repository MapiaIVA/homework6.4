public class City {
    private String name;
    private String country;
    private int region;
    private int people;
    private int index;
    private int phone;


    private static int counter = 0;

    public City(String name, String country,  int region, int people, int index, int phone) {
        this.name = name;
        this.region = region;
        this.country = country;
        this.people = people;
        this.index = index;
        this.phone = phone;
    }

    public City() {
        this.name = "Kaliningrad";
        this.region = 39;
        this.country = "Russia";
        this.people = 500000;
        this.index = 4012;
        this.phone = 893219320;
        counter++;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    public int getPeople() {
        return people;
    }

    public void setPeople(int people) {
        this.people = people;
    }
    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }
    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }






    @Override
    public String toString() {
        return name + " " + country + " " + index + " " + people + " " + phone + " " + region + "\n" + counter;
    }
}


