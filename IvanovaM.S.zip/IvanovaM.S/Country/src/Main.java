public class Main {
    public static void main(String[] args) {
        Country Russia = new Country();
        System.out.println(Russia);

    }
}
