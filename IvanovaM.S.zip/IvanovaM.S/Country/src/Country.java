public class Country {
    private String name;
    private String continent;
    private String capital;
    private int people;
    private int index;
    private String city;


    private static int counter = 0;

    public Country(String name, String continent,  String city, String capital, int people, int index) {
        this.name = name;
        this.capital = capital;
        this.city = city;
        this.people = people;
        this.index = index;
        this.continent = continent;
    }

    public Country() {
        this.name = "Russia";
        this.capital = "Moscow";
        this.city = "Moscow, Kaliningrad, Vologda";
        this.people = 15000000;
        this.index = 238710;
        this.continent = "Eurasia";
        counter++;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
    public void setContinent(String continent) {
        this.continent = continent;
    }
    public String getContinent() {
        return continent;
    }

    public String getCapital() {
        return capital;
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }
    public int getPeople() {
        return people;
    }

    public void setPeople(int people) {
        this.people = people;

    }
    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }






    @Override
    public String toString() {
        return name + " " + continent + " " + index + " " + people + " " + capital + " " + city + "\n" + counter;
    }
}


