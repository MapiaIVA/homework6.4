import java.security.KeyStore;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        class Fish {

            String name;
            double price;
            double weight;

            public Fish(String name, double weight, double price) {
                this.name = name;
                this.price = price;
                this.weight = weight;
            }
            @Override
            public String toString() {
                return this.name + " Вес: " + this.weight + " Цена " + this.price;
            }
        }


//            public boolean equals(Object o) {
//                if (o == this) {
//                    return true;
//                }
//                if (!(o instanceof Fish)) {
//                    return false;
//                }
//                Fish tmp = (Fish) o;
//                return (tmp.name.equals(this.name) && tmp.weight == (this.weight) && tmp.price == (this.price));
//            }
//
//            public int hashCode() {
//                return this.name.hashCode();
//            }
//
//            public double getWeight() {
//                return this.weight;
//            }
//
//            public double getPrice() {
//                return this.price;
//            }
//



//
//
////            for(Map.Entry<Fish,Integer>entry:map.entrySet()){
////                Fish key = entry.getKey();
////                int b = entry.getValue();
////                System.out.println(key+" -> "+b);
////            }
//
//        }
//        Map<String, String> tm = new TreeMap<>();
//        tm.put("Brazil", "Brasilia");
//        tm.put("Canada", "Ottawa");
//        tm.put("Denmark","Copenhagen");
//        tm.put("Sweden","Stockholm");
//        tm.put("France","Paris");
//        tm.put("Russia","Moscow");
//        for (Map.Entry e:tm.entrySet()) {
//            System.out.println(e.getKey()+" "+e.getValue());
//
//        }
//        Iterator iterator = tm.entrySet().iterator();
//        while (iterator.hasNext()) {
//            Map.Entry entry = (Map.Entry)iterator.next();
//            String key = (String) entry.getValue();
//            String value = (String) entry.getValue();
//
//            System.out.println(key+ "->" + value);
//
//        }
//        List keyList = new ArrayList(tm.keySet());
//        List valueList = new ArrayList(tm.values());
//
//        Map<Fish,Double> tms = new TreeMap<>(new Comparator<Fish>() {
//            @Override
//            public int compare(Fish o1, Fish o2) {
//                return (int)(o1.getPrice() * 100 - o2.getPrice() * 100);
//            }
//        });
//
//        Map<Fish, Integer> map = new LinkedHashMap<>();
        Fish fish1 = new Fish("Vobla", 12.5, 120);
        Fish fish3 = new Fish("Tuna", 2.3, 210);
        Fish fish4 = new Fish("Losos", 5.9, 150);
//        Fish fish5 = new Fish("Kilka", 6.4, 145);
//        Fish fish2 = new Fish("Salmon", 6.4, 145);
//
//        tms.put(fish1,120.0);
//        tms.put(fish2,145.0);
//        tms.put(fish3,210.0);
//        tms.put(fish4,150.0);
//        tms.put(fish5,1000.0);

//        for (Object eo:tms.entrySet()) {
//            Map.Entry e = (Map.Entry)eo;
//            System.out.println(e.getKey() + "--->" + e.getValue());
//     }
        Map<Fish,Double> wtm = new WeakHashMap<>();
        wtm.put(fish1,120.0);
        wtm.put(fish3,180.0);
        wtm.put(fish4,220.0);
        System.out.println("Before: ");
        for (Object o: wtm.entrySet()){
            Map.Entry e =(Map.Entry)o;
            System.out.println(e.getKey() + "-->" + e.getValue());
        }
        fish3 = null;
        for (int i = 0; i < 1000; i++) {
            byte[] b = new byte[100000];
            b = null;
        }
        System.out.println("After: ");
        for (Object o: wtm.entrySet()){
            Map.Entry e =(Map.Entry)o;
            System.out.println(e.getKey() + "-->" + e.getValue());
        }


    }
}

