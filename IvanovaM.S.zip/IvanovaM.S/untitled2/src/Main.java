import java.util.*;

public class Main {
    public static void main(String[] args) {

//        ArrayList<String>List1 = new ArrayList<String>();
//        ArrayList<Fish>list2 = new ArrayList<Fish>();
//        ArrayList<Object>list3 = new ArrayList<Object>();
//        ArrayList<String> a1 = new ArrayList<>();
//        a1.add("Argentina");
//        a1.add("Russia");
//        a1.add("Bulgaria");
//        a1.add("Denmark");
//        a1.add("Canada");
//        System.out.println("Collection: " + a1);
//        System.out.println("Collections size: " + a1.size());
//        System.out.println(a1.get(1));
//        if (!a1.contains("England")) {
//            System.out.println("England is not in Collection");
//            a1.set(4, "England");
//        }
//        System.out.println("Collection: " + a1);
//        System.out.println("Collections size: " + a1.size());
//        System.out.println(a1.indexOf("England"));
//        int ie=a1.indexOf("England");
//        a1.set(ie, "United Kingdom");
//        System.out.println("Collection: " + a1);
//        System.out.println("Collections size: " + a1.size());
//        System.out.println("Collection Using For Loop: ");
//        for (int i = 0; i<a1.size(); i++) {
//            System.out.println(a1.get(i));
//        }
//        System.out.println("\n Collection Using While loop: ");
//        int i = 0;
//        while (i<a1.size()) {
//            System.out.println(a1.get(i));
//            i++;
//        }
//        System.out.println("\n Collection Using Advanced For Loop: ");
//        for (Object a:a1) {
//            System.out.println(a);
//        }
//        System.out.println("\n Collection Using Iterator: ");
//        Iterator<String>iterator = a1.iterator();
//        while (iterator.hasNext()) {
//            System.out.println(iterator.next());
//        }
//        a1.trimToSize();
//        a1.ensureCapacity(100);
//        String [] array = (String[]) a1.toArray();
//
        LinkedList<String> ll = new LinkedList<String>();
        ll.add("one");
        ll.add("two");
        ll.add("three");
        ll.add("four");
        ll.add("five");
        System.out.println("List: " + ll);
        ll.addLast("six");
        ll.add(3, "three");
        ll.addFirst("zero");
        System.out.println("List: " + ll);
        ll.remove("three");
        //  ll.remove(3);
        System.out.println("List: " + ll);
        System.out.println("loop for: ");
        for (int i = 0; i < ll.size(); i++) {
            System.out.println(ll.get(i));
        }
        ListIterator<String> it_beg = ll.listIterator();
        System.out.println("Loop forward: ");
        while (it_beg.hasNext()) {
        System.out.println(it_beg.next());
    }
        System.out.println("Loop backward");
        while (it_beg.hasPrevious()) {
            System.out.println(it_beg.previous());
        }
        ListIterator<String>it_index= ll.listIterator(4);
        System.out.println("Loop from index: ");
        while (it_index.hasNext()){
            System.out.println(it_index.next());
        }
        Iterator<String>it_desc = ll.descendingIterator();
        System.out.println("Loop with  descending Iterator");
        while (it_desc.hasNext()){
            System.out.println(it_desc.next());
        }
        it_index.set("6");
        it_index.set("7");

        Collections.sort(ll);
        System.out.println("Sorted List: ");
        for (String s: ll) {
            System.out.println(s);
        }
    }
}

