import java.util.Arrays;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        System.out.println(isSimple(10));
        int number = C.MethodThatReturnSumOfNumbers(1, 3, 5, 5, 3, 1);
        int[] array = createRandomArray(10, 15);
        System.out.println(Arrays.toString(array));
        System.out.println("Сумма элементов массива равна: " + arraySum(array));
        // int[] arr = task212(1, 3, 5);
        // System.out.println(arr);
        System.out.println(" Cумма элементов массива = " + Arrays.toString(task1(5, 8, 6)));

    }

    static int[] createRandomArray(int count, int max) {
        int[] array = new int[count];
        Random rand = new Random();
        for (int i = 0; i < count; i++) {
            array[i] = rand.nextInt(max);
        }
        return array;
    }

    static int arraySum(int[] array) {
        int sum = 0;
        for (int i = 0; i < array.length; i++) {
            sum += array[i];
        }
        return sum;
    }

//    static int[] task212(int[] g, int[] k, int[] t) {
//        int max = g[0];
//        for (int i = 1; i < .length; i++) {
//            if (arr[i] > max) {
//                max = arr[i];
//            }
//        }
//        return g;
//    }
        static int [] task1 (int c, int n, int k) {
            int summ = 0;
            summ = c + n + k;
            
            return new int[]{summ};
        }


    class C {
        static int MethodThatReturnSumOfNumbers(int x, int y, int z, int q, int c, int r) {
            if (x + y + z == q + c + r) {
                System.out.println("true");
            }
            if (x + y + z != q + c + r) {
                System.out.println("false");
                return x;
            }
            return x;
        }

    }

    public static boolean isSimple(Integer number) {
        if(number < 2) return false;
        for(int i = 2; i < number / 2; i++) {
            if(number % i == 0) {
                return false;
            }
        }
        return true;
    }

}
