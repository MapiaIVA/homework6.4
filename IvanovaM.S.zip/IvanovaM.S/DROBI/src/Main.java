public class Main {
    public static void main(String[] args) {
        System.out.println("Дробь:");
        Fraction firstFraction = new Fraction(3, 5);
        Fraction secondFraction = new Fraction(1, 10);

        System.out.println("Сумма дробей: " + firstFraction.add(secondFraction));

        System.out.println("Разница дробей: " + firstFraction.minus(secondFraction));
        Fraction multip = new Fraction (6, 10);
        System.out.println(multip);
//        System.out.println(multi p());
    }

}