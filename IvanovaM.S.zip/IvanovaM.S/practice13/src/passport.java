public class passport {
    public static void main(String[] args) {
        Human Ivan = new Human("Иванов Иван Иванович", "Moscow", "Russia", "red", 25121991, 892132435);
        System.out.println(Ivan);
        Ivan.setCity("SPB");
        System.out.println(Ivan.getCity());
        Human Sergey = new Human();
        Human Sergey1 = new Human();
        System.out.println(Ivan);

    }
}
