public class Human {
    private String fio;
    private String city;
    private String country;
    private String address;
    private int birth;
    private int phone;


    private static int counter = 0;

    public Human(String fio, String city, String country, String address, int birth, int phone) {
        this.fio = fio;
        this.city = city;
        this.country = country;
        this.address = address;
        this.birth = birth;
        this.phone = phone;
    }

    public Human() {
        this.fio = "Ivanov Ivan Ivanovich";
        this.city = "Moscow";
        this.country = "Russia";
        this.address = "Red Square";
        this.birth = 19121995;
        this.phone = 893219320;
        counter++;
    }

    public String getFio() {
        return fio;
    }

    public void setFio(String fio) {
        this.fio = fio;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }
    public int getBirth() {
        return birth;
    }

    public void setBirth(int birth) {
        this.birth = birth;
    }






    @Override
    public String toString() {
        return fio + " " + country + " " + city + " " + address + " " + phone + " " + birth + "\n" + counter;
    }
}


