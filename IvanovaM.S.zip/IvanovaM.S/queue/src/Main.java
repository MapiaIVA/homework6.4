import java.util.*;

public class Main {
    public static void main(String[] args) {
//        PriorityQueue <Integer> priorityQueue = new PriorityQueue<>();
//        priorityQueue.add(4);
//        priorityQueue.add(3);
//        priorityQueue.add(1);
//        priorityQueue.add(9);
//        priorityQueue.add(5);
//        priorityQueue.add(6);
//        priorityQueue.add(7);
//        priorityQueue.add(3);
//
//        System.out.println("Collection: " + priorityQueue);
//        System.out.println("Collection size: " + priorityQueue.size());
//        System.out.println(priorityQueue.poll()); // deleted first element
//        System.out.println("First element: " + priorityQueue.peek());
//        System.out.println("Collection size: " + priorityQueue.size());
//        System.out.println("Collection: " + priorityQueue);
//
//        System.out.println("\n Collection Using Iterator: ");
//        Iterator <Integer> iterator = priorityQueue.iterator();
//        while (iterator.hasNext()) {
//            System.out.println(iterator.next());
//        }
//        Comparator <Integer> comparator = new Comparator<Integer>() {
//            @Override
//            public int compare(Integer o1, Integer o2) {
//                if (o1>o2) {
//                    return -1;
//                }
//                if (o1<o2) {
//                    return 1;
//                }
//                return 0;
//            }
//        };
//        Queue <Integer> pq = new PriorityQueue<>(comparator);
//        pq.add(4);
//        pq.add(3);
//        pq.add(5);
//        pq.add(9);
//        pq.offer(1);
//
//        Iterator<Integer> iterator = pq.iterator();
//        while (iterator.hasNext()) {
//            System.out.println(iterator.next());
//        }
//        System.out.println(pq.size());
//        System.out.println("Removing elements from the queue: ");
//        while (!pq.isEmpty()) {
//            System.out.println(pq.remove());
//            System.out.println(pq);
//        }
//        System.out.println(pq);
//      //  System.out.println(pq.remove());
//        System.out.println(pq.size());
//        HashMap<String, Integer> hashMap = new HashMap<String, Integer>();
//        hashMap.put("Argentina", 1);
//        hashMap.put("Norway", 12);
//        hashMap.put("Canada", 10);
//        hashMap.put("USA", 5);
//        for (Map.Entry m : hashMap.entrySet()) {
//            System.out.println(m.getKey() + " " + m.getValue());
//        }
//        int value = hashMap.get("Argentina");
//        hashMap.put("Argentina", value + 5);
//        System.out.println("New value on key for Argentina: " + hashMap.get("Argentina"));
//        for (Map.Entry m : hashMap.entrySet()) {
//            System.out.println(m.getKey() + " " + m.getValue());
//        }
        class Fish {
            String name;
            double price;
            public Fish(String name, double price) {
                this.price = price;
                this.name = name;
            }
        }
        Map<Integer, Fish> map = new HashMap<>();
        Fish f1 = new Fish("Vobla", 2.55);
        Fish f2 = new Fish("Salmon", 7.40);
        Fish f3 = new Fish("Kilka", 4.1);
        Fish f4 = new Fish("", 2.55);


    }
}




