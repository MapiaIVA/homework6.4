import java.util.*;

public class Main {
    public static void main(String[] args) {
        class Auto {

            String name;
            double price;
            String color;

            public Auto(String name, String color, double price) {
                this.name = name;
                this.price = price;
                this.color = color;
            }

            @Override
            public String toString() {
                return this.name + " Цвет: " + this.color + " Цена: " + this.price;
            }

            public int hashCode() {
                return this.name.hashCode();
            }

            public String getColor() {
                return this.color;
            }

            public String getName() {
                return this.name;
            }

            public double getPrice() {
                return this.price;
            }

            public boolean equals(Object o) {
                if (o == this) {
                    return true;
                }
                if (!(o instanceof Auto)) {
                    return false;
                }
                Auto tmp = (Auto) o;
                return (tmp.name.equals(this.name) && tmp.color == (this.color) && tmp.price == (this.price));
            }

        }

        Map<Auto, Double> tm = new HashMap<>();
        Auto car1 = new Auto("Ford", "red", 1400.5);
        Auto car2 = new Auto("Ford", "red", 1400.5);
        Auto car3 = new Auto("Audi", "white", 2000.0);
        Auto car4 = new Auto("BMW", "Blue", 3400.550);
        Auto car5 = new Auto("Audi", "grey", 1900.5);
        tm.put(car1, 1400.5);
        tm.put(car2, 1400.5);
        tm.put(car3, 2000.0);
        tm.put(car4, 3400.550);
        tm.put(car5, 1900.5);
        for (Map.Entry<Auto, Double> entry : tm.entrySet()) {
            Auto key = entry.getKey();
            Double b = entry.getValue();
            System.out.println(key + " -> " + b);

        }
    }
}

