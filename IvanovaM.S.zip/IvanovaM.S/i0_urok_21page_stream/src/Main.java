import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    public static void main(String[] args) {
        FileOutputStream fout = null;
        ObjectOutputStream oout = null;
        try {
            fout = new FileOutputStream("test.txt");
            Fish f = new Fish("salmon", 2.5,200);

            oout = new ObjectOutputStream(fout);
            oout.writeObject(f);

        } catch (FileNotFoundException e) {
            Logger.getLogger(File.class.getName()).log(Level.SEVERE,null,e);
        } catch (IOException e) {
            Logger.getLogger(File.class.getName()).log(Level.SEVERE,null,e);
        } finally {
            try {
                oout.close();
            } catch (IOException e) {
                Logger.getLogger(File.class.getName()).log(Level.SEVERE,null,e);
            }
        }
        FileInputStream fin = null;
        try {
            fin = new FileInputStream(new File("test.txt"));
            ObjectInputStream oin = new ObjectInputStream(fin);
            Fish f1 = (Fish) oin.readObject();
            System.out.println(f1);

        } catch (FileNotFoundException e) {
            Logger.getLogger(File.class.getName()).log(Level.SEVERE,null,e);
        } catch (IOException e) {
            Logger.getLogger(File.class.getName()).log(Level.SEVERE,null,e);
        } catch (ClassNotFoundException e){
            Logger.getLogger(File.class.getName()).log(Level.SEVERE,null,e);
        }

        finally {
            try {
                fin.close();
            } catch (IOException e) {
                Logger.getLogger(File.class.getName()).log(Level.SEVERE,null,e);
            }
        }

    }
}

class Fish implements  Serializable {
    String name;
    double price;
    double weight;

    public Fish(String name, double price, double weight) {
        this.name = name;
        this.price = price;
        this.weight = weight;
    }

    public String getName() {
        return this.name;
    }

    public double getPrice() {
        return this.price;
    }

    public double getWeight() {
        return this.weight;
    }

    @Override
    public String toString() {
        return "Name: " + this.name + " Price: " + this.price + " Weight: " + this.weight;
    }
}
//    public void showFish() {
//        System.out.println("Name: " + this.name + " Price: " + this.price + " Weight: " + this.weight);
//    }
//}