public class auto1  {
    public static void main(String[] args) {
        Auto Ford = new Auto();
        System.out.println(Ford);

    }
}

