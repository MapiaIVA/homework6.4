public class Auto {
    private String name;
    private int year;
    private String creator;
    private int engine;


    private static int counter = 0;

    public Auto(String name, String creator, int year, int engine) {
        this.name = name;
        this.creator = creator;
        this.year = year;
        this.engine = engine;
    }

    public Auto() {
        this.name = "Ford";
        this.creator = "Ford Model";
        this.year = 2010;
        this.engine = 2;
        counter++;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
    public int getEngine() {
        return engine;
    }

    public void setEngine(int engine) {
        this.engine = engine;
    }






    @Override
    public String toString() {
        return name + " " + creator + " " + engine + " " + year + " " + "\n" + counter;
    }
}


