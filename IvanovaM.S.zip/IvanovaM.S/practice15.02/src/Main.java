import java.time.LocalDate;
import java.util.Date;

@FunctionalInterface
interface MyInterface<T> {
    int func(int a, int b);
}
@FunctionalInterface
interface MyInterface2<T> {
    int func(int a);
}
@FunctionalInterface
interface Summa<T> {
    int func1(int a, int b, int c);
}
interface Mnozit<T> {
    int func2(int a, int b, int c);
}
@FunctionalInterface
interface Stroka {
    String stroka (String a, String b);
}
@FunctionalInterface
interface CurrentTime {
    void printTime();
}

@FunctionalInterface
interface CurrentDate {
    void printDate();
}
@FunctionalInterface
interface Max <T> {
    int max(int a, int b);
}
@FunctionalInterface
interface MyInterface1<T> {
    T func(T t);
}

public class Main {
    public static void main(String[] args) {
        MyInterface myInterface = (n, v) -> {
            return n + v;
        };
        System.out.println("Сумма чисел: " + myInterface.func(4, 6));

        Stroka stringStroka = (str1, str2) -> {
            return str1 + str2;
        };
        System.out.println("Контантенация строк: " + stringStroka.stroka("drfks", "Dhjfshk"));
        Summa summa = (a, b, c) -> {
            return a + b + c;
        };
        System.out.println("Сумма чисел: " + summa.func1(4, 6, 5));

        Mnozit mnozit = (a, b, c) -> {
            return a * b * c;
        };
        System.out.println("Сумма чисел: " + mnozit.func2(4, 6, 5));

        CurrentTime currentTime = () -> {
            Date date = new Date();
            System.out.println("Текущее времяя: " + date);
        };
        currentTime.printTime();

        currentTime.printTime();
        CurrentDate currentDate = () -> {


            LocalDate localDate = LocalDate.now();
            System.out.println("Текущая дата: " + localDate);
        };
        currentDate.printDate();

        Max max = (a, b) -> {
            if (a > b) {
                return a;
            } else {
                return b;
            }
        };

        System.out.println("Максимум из двух чисел: " + max.max(5, 6));
        Max max1 = (a, b) -> {
            if (a < b) {
                return a;
            } else {
                return b;
            }
        };

        System.out.println("Максимум из двух чисел: " + max1.max(5, 6));
        MyInterface1<Integer> factorial = (n) -> {
            int result = 1;
            for (int i = 1; i <= n; i++) {
                result = i * result;
            }
            return result;
        };

        System.out.println("Факториал от 5 = : " + factorial.func(5));
//        MyInterface myInterface2 = (n) -> {
//                if (n < 2)
//                    return false;
//
//                for (int i = 2; i <= n; i++) {
//                    if (n % i == 0)
//                        return false;
//                }
//                return true;
//
//            };
//        System.out.println("Сумма чисел: " + myInterface2.func2(4));
        MyInterface2 myInterface2 = (z) -> {
            if (z <= 1) {
                return 0;
            }
            for (int i = 2; i < Math.sqrt(z); i++) {
                if (z % i == 0) {
                    return 0;
                }
            }

            return 1;
        };
        if (myInterface2.func(29) == 0) {
            System.out.println("не является");
        } else {
            System.out.println("является");
        }
    }
}












//сумма двух чисел и складывает две строки